import threading
import time
import cv2 as cv
import os
import pygame
import sys
from pygame.locals import *
from periphery import GPIO
import psutil
import subprocess
import socket

#start_play = False
playing = False
t = None
QA = ''
index = 0
isListening = True
drivers = ['/dev/fb1']
currentip='' #当前IP
frames = [] #pygame不支持播放gif，所以把gif转换成图片，依次显示图片
for i in range(1,42):
    if i <10:
        frames.append("/home/pi/WorkSpace/LCD/data/frame_0"+str(i)+"_delay-0.13s.gif")
    elif i <100:
        frames.append("/home/pi/WorkSpace/LCD/data/frame_"+str(i)+"_delay-0.13s.gif")
    else:
        frames.append("/home/pi/WorkSpace/LCD/data/frame_"+str(i)+"_delay-0.02s.gif")

def play_anim(screen, tt):
    global playing

    anim = cv.VideoCapture("data/ai.mp4")

    t = time.time()

    while (time.time() - t < tt):
        ret, frame = anim.read()
        print("frame: " + str(frame.shape))

        frame = cv.resize(frame, (240, 135))

        frame = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
        frame = cv.transpose(frame)
        frame = pygame.surfarray.make_surface(frame)
        screen.blit(frame, (0, 0))
        pygame.display.update()

        cv.waitKey(30)





class pyscope:
    screen = None;

    def __init__(self):
        disp_no = os.getenv("DISPLAY")
        if disp_no:
            print("I'm running under X display = " + str(disp_no))

        found = False
        for driver in drivers:
            # Make sure that SDL_VIDEODRIVER is set
            if not os.getenv('SDL_FBDEV'):
                os.putenv('SDL_FBDEV', driver)
            try:
                pygame.display.init()
            except pygame.error:
                print("Driver: " + str(driver) + "failed.")
                continue
            found = True
            break

        if not found:
            raise Exception('No suitable video driver found!')

        size = (pygame.display.Info().current_w, pygame.display.Info().current_h)
        print("Framebuffer size: %d x %d" % (size[0], size[1]))
        self.screen = pygame.display.set_mode(size, pygame.FULLSCREEN)
        # Clear the screen to start
        self.screen.fill((0, 0, 0))
        # Initialise font support
        pygame.font.init()
        self.font = pygame.font.Font("/home/pi/WorkSpace/LCD/data/consolaz.ttf", 80)
        self.font_chinese1 = pygame.font.Font("/home/pi/WorkSpace/LCD/data/SIMYOU.TTF", 30)
        self.font_chinese2 = pygame.font.Font("/home/pi/WorkSpace/LCD/data/SIMYOU.TTF", 23)
        self.font_chinese3 = pygame.font.Font("/home/pi/WorkSpace/LCD/data/msyhbd.ttc", 23)
        self.font_chinese4 = pygame.font.Font("/home/pi/WorkSpace/LCD/data/msyhbd.ttc", 18)


        pygame.mouse.set_visible(False)
        # Render the screen
        pygame.display.update()

    def __del__(self):
        "Destructor to make sure pygame shuts down, etc."

    def test(self):
        # Fill the screen with red (255, 0, 0)
        import socket
        # ip = ''
        self.screen.fill((0, 0, 0))

        #global start_play
        global playing
        global index
        global isListening
        def showByIndex(index):
            if index>0:
                index = index%2   #2是页面数量，自己加页面就把2改了
            if(index==0):
                global t
                if (t != time.strftime('%H:%M:%S', time.localtime(time.time()))):
                    t = time.strftime('%H:%M:%S', time.localtime(time.time()))
                    self.screen.fill((0, 0, 0))
                    ts = t.split(":")
                    text_mt = self.font.render(ts[0] + (":" if int(ts[2]) % 2 == 0 else " ") + ts[1], True, (219, 108, 28))
                    self.screen.blit(text_mt, (10, 30))
                    # ip_mt = self.font_chinese4.render(ip,True, (219, 108, 28))
                    # self.screen.blit(ip_mt, (110, 110))
                    pygame.display.update()
            elif (index==1):
                try:
                    global currentip
                    self.screen.fill((0, 0, 0))
                    recv1 = psutil.net_io_counters(pernic=True)['wlan0'][1] #接收数据
                    send1 = psutil.net_io_counters(pernic=True)['wlan0'][0] #上传数据
                    time.sleep(1)  # 每隔1s监听端口接收数据
                    recv2 = psutil.net_io_counters(pernic=True)['wlan0'][1]
                    send2 = psutil.net_io_counters(pernic=True)['wlan0'][0]
                    text_mt = self.font_chinese4.render('upload:%.1f kb/s;' % ((send2 - send1) / 1024.0), True, (219, 108, 28))
                    text_mt2 = self.font_chinese4.render('download:%.1f kb/s;' % ((recv2 - recv1) / 1024.0), True, (219, 108, 28))
                    text_mt3 = self.font_chinese4.render('cpu:'+str(psutil.cpu_percent(interval=1, percpu=False))+'%', True, (219, 108, 28))
                    text_mt4 = self.font_chinese4.render('memory:'+str(psutil.virtual_memory().percent)+'%', True, (219, 108, 28))
                    temperature = str(psutil.sensors_temperatures()['cpu_thermal'][0].current)[0:4]+'℃'
                    text_mt5 = self.font_chinese4.render('temperature:'+temperature, True, (219, 108, 28))
                    text_mt6 = self.font_chinese4.render('ip:'+currentip, True, (219, 108, 28))
                    self.screen.blit(text_mt, (10, 5))
                    self.screen.blit(text_mt2, (10, 25))
                    self.screen.blit(text_mt3, (10, 45))
                    self.screen.blit(text_mt4, (10, 65))
                    self.screen.blit(text_mt5, (10, 85))
                    self.screen.blit(text_mt6, (10, 105))
                    pygame.display.update()
                except Exception as e:
                    time.sleep(0.2)
            elif (index==-2):
                try:
                    for i in frames:
                        img = pygame.image.load(i)
                        self.screen.blit(img,(0,0))
                        pygame.display.update()
                        time.sleep(0.13)
                except Exception as e:
                    pass
            elif (index==-1):
                try:
                    self.screen.fill((0, 0, 0))
                    global QA #本来是想显示问题+答案，现在只显示了答案，有需要自己改
                    # Question = QA.split('&&')[0]
                    # Answer = QA.split('&&')[1]
                    # pagesize = 15
                    # Q_maxpage = len(Question)/pagesize
                    # A_maxpage = len(Answer)/pagesize
                    # page = 0
                    # while page <= Q_maxpage:
                    #     text_mt = self.font_chinese3.render(Question[page*pagesize:(page+1)*pagesize], True, (219, 108, 28))
                    #     self.screen.blit(text_mt, (10, 10+(40*page)))
                    #     page += 1
                    # page = 0
                    # while page <= A_maxpage:
                    #     text_mt = self.font_chinese3.render(Answer[page*pagesize:(page+1)*pagesize], True, (219, 108, 28))
                    #     self.screen.blit(text_mt, (10, 10+40*(page+Q_maxpage+1)))
                    #     page += 1
                    text_mt = self.font_chinese3.render(QA, True, (255, 255, 255))
                    self.screen.blit(text_mt, (10, 10))
                    pygame.display.update()
                except Exception as e:
                    text_mt = self.font_chinese4.render(str(e), True, (219, 108, 28))
                    self.screen.blit(text_mt, (10, 10))
                    pygame.display.update()
                    
        index=0
        while True:
            showByIndex(index)
            time.sleep(0.1)

            

class MyThread(threading.Thread):
    def __init__(self,n):
        super(MyThread,self).__init__()   #重构run函数必须写
        self.n = n
    def run(self):
        global dict1
        global currentip
        try:
            while True:
                try: 
                    s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM) 
                    s.connect(('8.8.8.8',80)) 
                    currentip = s.getsockname()[0]
                    s.close()
                except Exception as e:
                    pass
                time.sleep(60)
        except Exception as e:
            fo = open("/home/pi/WorkSpace/LCD/foo.txt", "a+")
            fo.write(str(e)+'\n')
            fo.close()




class MyThread2(threading.Thread):
    def __init__(self,n):
        super(MyThread2,self).__init__()   #重构run函数必须写
        self.n = n
    def run(self):
        gpio_key = GPIO("/dev/gpiochip1", 3, "in")
        global index
        while True:
            if(gpio_key.read()==False):
                time_start = time.time()
                while(gpio_key.read()==False):
                    time.sleep(0.2)
                    if(time.time() - time_start > 1):
                        index+=1
                        break
            time.sleep(0.1)

class MyThread3(threading.Thread):
    def __init__(self,n):
        super(MyThread3,self).__init__()   #重构run函数必须写
        self.n = n
    def run(self):
        try:
            s = socket.socket()
            host = socket.gethostname()
            port = 12345 
            s.bind((host, port))
            s.listen(1)
            global index
            while True:
                c,addr = s.accept()
                data = c.recv(1024).decode()#如192.168.43.202
                if ( data == 'isListening'):
                    index = -2
                    time.sleep(5)
                    index = -1
                else:
                    global QA
                    QA = data
                    index = -1
                    time.sleep(5)
                    QA = ''
                    index = 0
            s.close()
        except Exception as e:
            print(e)
            time.sleep(0.2)
        


t1 = MyThread('freshdata') #刷新数据，目前只有刷新IP
t1.start()

t2 = MyThread2('gpio') #监听按钮
t2.start()

t3 = MyThread3('socket') #与wukong通信
t3.start()

# Create an instance of the PyScope class
scope = pyscope()
scope.test()
